chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete') {
        return;
    }

    if (!tab || !tab.url || !/^https?:/i.test(tab.url)) {
        return;
    }

    void (async () => {
        const sidebarState = await loadCardSidebarState().catch(() => null);
        if (!sidebarState || sidebarState.open !== true || Number(sidebarState.tabId || 0) !== Number(tabId)) {
            return;
        }

        await injectCardEditorSidebar(Number(tabId), sidebarState.width || 820).catch(() => {});
    })();
});

chrome.tabs.onRemoved.addListener((tabId) => {
    void (async () => {
        const sidebarState = await loadCardSidebarState().catch(() => null);
        if (sidebarState && Number(sidebarState.tabId || 0) === Number(tabId)) {
            await clearCardSidebarState();
        }

        const controlState = await loadStandaloneDebugControlState().catch(() => null);
        if (controlState && Number(controlState.tabId || 0) === Number(tabId)) {
            await clearStandaloneDebugControlState();
        }
    })();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message !== 'object') {
        return false;
    }

    if (message.type === 'cookie-capture-start') {
        (async () => {
            try {
                const result = await captureCurrentTab(message.payload || {});
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '抓取失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'cookie-capture-clear-current-page-cache') {
        (async () => {
            try {
                const payload = message.payload && typeof message.payload === 'object' ? message.payload : {};
                const result = await clearCurrentPageCache(payload.tabId || 0);
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '清理当前页面缓存失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'cookie-capture-import-cookies') {
        (async () => {
            try {
                const payload = message.payload && typeof message.payload === 'object' ? message.payload : {};
                const result = await importSnapshotToCurrentPage(
                    payload.tabId || 0,
                    payload.pageUrl || payload.tabUrl || '',
                    payload.cookies || [],
                    payload.browserStorage || []
                );
                const importedCount = Number(result.importedCount || 0) || 0;
                const failedCount = Number(result.failedCount || 0) || 0;
                const storageCount = Number(result.browserStorageCount || 0) || 0;
                const restoredLocalStorageCount = Number(result.restoredLocalStorageCount || 0) || 0;
                const restoredSessionStorageCount = Number(result.restoredSessionStorageCount || 0) || 0;
                const responseParts = [];
                if (storageCount > 0) {
                    responseParts.push(`浏览器存储 ${storageCount} 组`);
                }
                if (restoredLocalStorageCount > 0) {
                    responseParts.push(`localStorage ${restoredLocalStorageCount} 项`);
                }
                if (restoredSessionStorageCount > 0) {
                    responseParts.push(`sessionStorage ${restoredSessionStorageCount} 项`);
                }
                if (importedCount > 0) {
                    responseParts.push(`Cookie ${importedCount} 条`);
                }
                if (failedCount > 0) {
                    responseParts.push(`失败 ${failedCount} 条${result.firstError ? `，首个错误：${result.firstError}` : ''}`);
                }
                const responseMessage = responseParts.length > 0
                    ? `已导入 ${responseParts.join('，')}，请刷新页面生效`
                    : result.message || '未导入任何内容';
                sendResponse({
                    ...result,
                    success: result.success === true,
                    message: responseMessage,
                    error: result.success === true ? '' : responseMessage
                });
            } catch (error) {
                sendResponse({
                    success: false,
                    message: error && error.message ? error.message : 'Cookie 注入失败',
                    error: error && error.message ? error.message : 'Cookie 注入失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'standalone-registration-start') {
        (async () => {
            try {
                const payload = message.payload && typeof message.payload === 'object' ? message.payload : {};
                const loopRegistration = payload.loopRegistration === true;
                let result = null;

                do {
                    result = await runStandaloneRegistration({
                        ...payload,
                        loopRegistration
                    });

                    const success = result?.success === true;
                    const currentControlState = await loadStandaloneDebugControlState().catch(() => null);
                    const stopRequested = Boolean(
                        currentControlState
                        && (currentControlState.stopRequested === true || currentControlState.running === false)
                    );
                    const stopped = result?.stopped === true || (loopRegistration && success && stopRequested);
                    const continuation = loopRegistration && success && !stopped && !stopRequested;

                    try {
                        const lastState = await loadStandaloneProgressState().catch(() => null);
                        await saveStandaloneProgressState({
                            ...(lastState && typeof lastState === 'object' ? lastState : {}),
                            tabId: lastState?.tabId || null,
                            cardName: String(result?.cardName || lastState?.cardName || payload?.cardData?.name || '').trim(),
                            message: String(continuation
                                ? `本轮注册完成: ${result.cardName || '未命名卡片'}`
                                : success
                                    ? `注册完成: ${result.cardName || '未命名卡片'}`
                                    : stopped
                                        ? `已停止注册: ${result.cardName || '未命名卡片'}`
                                        : result?.error || '注册失败'),
                            phase: continuation ? 'loop_iteration_finished' : success ? 'finished' : stopped ? 'stopped' : 'failed',
                            mode: continuation ? 'loop' : '',
                            loopRegistration: continuation,
                            kind: continuation || success || stopped ? '' : 'error',
                            errorReason: continuation || success || stopped ? '' : String(result?.error || '').trim(),
                            progress: continuation
                                ? 100
                                : success
                                    ? 100
                                    : stopped
                                        ? Number.isFinite(Number(lastState?.progress))
                                            ? Number(lastState.progress)
                                            : 0
                                        : 0,
                            running: continuation,
                            visible: true
                        });
                        await saveStandaloneDebugControlState({
                            tabId: lastState?.tabId || null,
                            cardName: String(result?.cardName || lastState?.cardName || payload?.cardData?.name || '').trim(),
                            mode: continuation ? 'loop' : 'pause',
                            stepBudget: 0,
                            running: continuation,
                            loopRegistration: continuation,
                            stopRequested: false
                        });
                    } catch (_error) {
                    }

                    try {
                        await chrome.runtime.sendMessage({
                            type: 'standalone-registration-finished',
                            success,
                            stopped,
                            continuation,
                            loopRegistration,
                            progress: success || continuation ? 100 : stopped ? Number(result?.progress || 0) : 0,
                            mode: continuation ? 'loop' : message.payload?.debugMode === true ? 'debug' : 'run',
                            errorReason: success || stopped ? '' : String(result?.error || '').trim(),
                            message: continuation
                                ? `本轮注册完成: ${result.cardName || '未命名卡片'}`
                                : success
                                    ? `注册完成: ${result.cardName || '未命名卡片'}`
                                    : stopped
                                        ? `已停止注册: ${result.cardName || '未命名卡片'}`
                                        : result?.error || '注册失败'
                        });
                    } catch (_error) {
                    }

                    if (!continuation) {
                        break;
                    }

                    const controlState = await loadStandaloneDebugControlState().catch(() => null);
                    if (!controlState || controlState.stopRequested === true || controlState.running === false) {
                        break;
                    }

                    await sleep(250);
                } while (true);

                sendResponse(result);
            } catch (error) {
                try {
                    const lastState = await loadStandaloneProgressState().catch(() => null);
                    await saveStandaloneProgressState({
                        ...(lastState && typeof lastState === 'object' ? lastState : {}),
                        tabId: lastState?.tabId || null,
                        cardName: String(message.payload?.cardData?.name || lastState?.cardName || '').trim(),
                        message: error && error.message ? error.message : '注册失败',
                        phase: 'failed',
                        mode: '',
                        loopRegistration: false,
                        kind: 'error',
                        errorReason: error && error.message ? error.message : '注册失败',
                        progress: Number.isFinite(Number(lastState?.progress)) ? Number(lastState.progress) : 0,
                        running: false,
                        visible: true
                    });
                    await saveStandaloneDebugControlState({
                        tabId: lastState?.tabId || null,
                        cardName: String(message.payload?.cardData?.name || lastState?.cardName || '').trim(),
                        mode: 'pause',
                        stepBudget: 0,
                        running: false,
                        loopRegistration: false
                    });
                } catch (_error) {
                }
                try {
                    await chrome.runtime.sendMessage({
                        type: 'standalone-registration-finished',
                        success: false,
                        progress: 0,
                        mode: message.payload?.debugMode === true ? 'debug' : 'run',
                        errorReason: error && error.message ? error.message : '注册失败',
                        message: error && error.message ? error.message : '注册失败'
                    });
                } catch (_error) {
                }
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '注册失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'standalone-registration-control') {
        (async () => {
            try {
                const payload = message.payload && typeof message.payload === 'object' ? message.payload : {};
                const requestedMode = String(payload.mode || 'loop').trim().toLowerCase();
                const controlState = await loadStandaloneDebugControlState().catch(() => null);
                const progressState = await loadStandaloneProgressState().catch(() => null);
                const tabId = Number(payload.tabId || controlState?.tabId || progressState?.tabId || 0);
                if (!tabId) {
                    sendResponse({ success: false, error: '当前没有可控制的调试任务' });
                    return;
                }

                const normalizedMode = requestedMode === 'step' || requestedMode === 'pause' ? requestedMode : 'loop';
                const existingBudget = Number(controlState?.stepBudget || 0) || 0;
                const nextStepBudget = normalizedMode === 'step'
                    ? (controlState?.mode === 'step' ? existingBudget + 1 : 1)
                    : 0;

                const saved = await saveStandaloneDebugControlState({
                    tabId,
                    cardName: controlState?.cardName || progressState?.cardName || '',
                    mode: normalizedMode,
                    stepBudget: nextStepBudget,
                    running: controlState?.running !== false && progressState?.running !== false
                });

                sendResponse({
                    success: true,
                    controlMode: saved.mode,
                    stepBudget: saved.stepBudget,
                    running: saved.running
                });
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '更新调试控制失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'standalone-registration-stop') {
        (async () => {
            try {
                const controlState = await loadStandaloneDebugControlState().catch(() => null);
                const progressState = await loadStandaloneProgressState().catch(() => null);
                const tabId = Number(controlState?.tabId || progressState?.tabId || 0);
                if (!tabId) {
                    sendResponse({ success: false, error: '当前没有正在运行的注册任务' });
                    return;
                }

                const cardName = String(controlState?.cardName || progressState?.cardName || '').trim();
                await saveStandaloneDebugControlState({
                    tabId,
                    cardName,
                    mode: controlState?.mode || 'pause',
                    stepBudget: 0,
                    running: false,
                    loopRegistration: false,
                    stopRequested: true
                });
                await saveStandaloneProgressState({
                    ...(progressState && typeof progressState === 'object' ? progressState : {}),
                    tabId,
                    cardName,
                    message: '正在停止注册流程...',
                    phase: 'stopping',
                    mode: '',
                    loopRegistration: false,
                    kind: '',
                    errorReason: '',
                    running: true,
                    visible: true
                });

                sendResponse({
                    success: true,
                    stopped: true
                });
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '停止注册失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'standalone-registration-sync-card') {
        (async () => {
            try {
                const payload = message.payload && typeof message.payload === 'object' ? message.payload : {};
                const senderTabId = Number(_sender?.tab?.id || 0);
                const result = await syncStandaloneRegistrationSession(payload, senderTabId);
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '同步调试卡片失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'temp-email-open') {
        (async () => {
            try {
                const result = await handleTempEmailOpen(message.payload || {});
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '打开浏览器失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'temp-email-get-email') {
        (async () => {
            try {
                const result = await handleTempEmailGetEmail(message.payload || {});
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '获取邮箱失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'temp-email-get-code') {
        (async () => {
            try {
                const result = await handleTempEmailGetCode(message.payload || {});
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '获取验证码失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'temp-email-close') {
        (async () => {
            try {
                const result = await handleTempEmailClose(message.payload || {});
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '关闭临时邮箱失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'temp-email-refresh') {
        (async () => {
            try {
                const result = await handleTempEmailRefresh(message.payload || {});
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '刷新验证码失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'open-card-editor-sidebar') {
        (async () => {
            try {
                const result = await openCardEditorSidebar(message.payload || {});
                sendResponse(result);
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '打开侧边栏失败'
                });
            }
        })();
        return true;
    }

    if (message.type === 'card-sidebar-state-update') {
        (async () => {
            try {
                const senderTabId = Number(_sender?.tab?.id || 0);
                if (!senderTabId) {
                    sendResponse({ success: false, error: '未找到侧边栏标签页' });
                    return;
                }

                const payload = message.payload && typeof message.payload === 'object' ? message.payload : {};
                await saveCardSidebarState({
                    tabId: senderTabId,
                    width: payload.width || 820,
                    open: payload.open === true
                });
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({
                    success: false,
                    error: error && error.message ? error.message : '更新侧边栏状态失败'
                });
            }
        })();
        return true;
    }

    return false;
});
