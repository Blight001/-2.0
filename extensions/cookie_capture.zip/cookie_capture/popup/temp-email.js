const shared = globalThis.CookieCaptureShared || {};
const { sanitizeFilePart, escapeHtml, normalizeCardData, showActionToast, downloadJsonFile, setCardFileName } = shared;

const TEMP_EMAIL_CARD_CACHE_LIST_KEY = 'cookie-capture-temp-email-card-cache-list';
const TEMP_EMAIL_CARD_SELECTED_ID_KEY = 'cookie-capture-temp-email-card-cache-selected-id';
const TEMP_EMAIL_CARD_CACHE_KEY = 'cookie-capture-temp-email-card-cache';
const TEMP_EMAIL_CARD_CACHE_NAME_KEY = 'cookie-capture-temp-email-card-cache-name';
const TEMP_EMAIL_CARD_CACHE_TIME_KEY = 'cookie-capture-temp-email-card-cache-time';

const tempEmailCardFileInput = document.getElementById('temp-email-card-file');
const tempEmailCacheBadgeNode = document.getElementById('temp-email-cache-badge');
const tempEmailCardCacheListNode = document.getElementById('temp-email-card-cache-list');

function normalizeTempEmailCardData(cardData, fileName = '') {
    if (!cardData || typeof cardData !== 'object' || Array.isArray(cardData)) {
        return {
            name: sanitizeFilePart(String(fileName || '').replace(/\.json$/i, '')) || '未命名临时邮箱卡片',
            providers: [],
            url: ''
        };
    }

    const providers = Array.isArray(cardData.providers) ? cardData.providers : [];
    const hasDirectProvider = Boolean(cardData.url);

    const normalized = { ...cardData };
    if (!String(normalized.name || '').trim()) {
        normalized.name = sanitizeFilePart(String(fileName || '').replace(/\.json$/i, '')) || '未命名临时邮箱卡片';
    }
    if (!Array.isArray(normalized.providers)) {
        normalized.providers = providers;
    }
    if (!String(normalized.url || '').trim()) {
        normalized.url = hasDirectProvider ? String(cardData.url || '').trim() : '';
    }

    return normalized;
}

function buildTempEmailCardCacheId(cardData = {}, sourceName = '') {
    const namePart = sanitizeFilePart(String(cardData?.name || sourceName || 'temp-email'));
    const timePart = new Date().toISOString().replace(/[:.]/g, '-');
    const randomPart = Math.random().toString(36).slice(2, 8);
    return `${namePart || 'temp-email'}_${timePart}_${randomPart}`;
}

function normalizeTempEmailCardCacheEntry(entry = {}, index = 0) {
    const source = entry && typeof entry === 'object' ? entry : {};
    const cardData = normalizeTempEmailCardData(source.cardData || source, source.cardName || source.name || `temp_email_${index + 1}`);
    return {
        id: String(source.id || source.cacheId || '').trim() || buildTempEmailCardCacheId(cardData, source.sourceName || source.fileName || source.cardName || ''),
        cardData,
        cardName: String(source.cardName || cardData.name || '').trim() || cardData.name,
        sourceName: String(source.sourceName || source.fileName || '').trim(),
        savedAt: String(source.savedAt || source.updatedAt || new Date().toISOString()).trim(),
        selected: source.selected === true
    };
}

function buildTempEmailCardListLabel(item = {}, isSelected = false) {
    const savedAt = String(item.savedAt || '').trim();
    const providerCount = Array.isArray(item.cardData?.providers) ? item.cardData.providers.length : 0;
    const savedAtText = savedAt ? (() => {
        const date = new Date(savedAt);
        return Number.isNaN(date.getTime()) ? savedAt : date.toLocaleString('zh-CN', { hour12: false });
    })() : '';
    const metaParts = [
        providerCount > 0 ? `${providerCount} 个站点` : '无站点',
        savedAtText
    ].filter(Boolean);
    return {
        title: String(item.cardData?.name || item.cardName || '未命名临时邮箱卡片').trim() || '未命名临时邮箱卡片',
        meta: metaParts.join(' · '),
        selected: isSelected
    };
}

function renderTempEmailCardCacheList(state = { items: [], selectedId: '' }) {
    if (!tempEmailCardCacheListNode) {
        return;
    }

    const items = Array.isArray(state.items) ? state.items : [];
    const selectedId = String(state.selectedId || '').trim();
    if (tempEmailCacheBadgeNode) {
        tempEmailCacheBadgeNode.textContent = items.length > 0 ? `${items.length} 张` : '0 张';
    }

    if (items.length === 0) {
        tempEmailCardCacheListNode.innerHTML = '<div class="card-cache-empty">暂无已缓存卡片，导入后会显示在这里。</div>';
        return;
    }

    tempEmailCardCacheListNode.innerHTML = items.map((item) => {
        const active = String(item.id || '').trim() === selectedId;
        const label = buildTempEmailCardListLabel(item, active);
        const timeText = label.meta ? `<div class="card-cache-item__meta">${escapeHtml(label.meta)}</div>` : '';
        return `
          <div class="card-cache-item${active ? ' is-active' : ''}" data-temp-email-card-item data-card-id="${escapeHtml(item.id)}">
            <div>
              <div class="card-cache-item__title">${escapeHtml(label.title)}</div>
              ${timeText}
            </div>
            <div class="card-cache-item__actions">
              ${active ? '<div class="chip">已选中</div>' : '<div class="chip">未选中</div>'}
              <button type="button" class="button-secondary" data-temp-email-card-action="select">选择</button>
            </div>
          </div>
        `;
    }).join('');
}

async function loadTempEmailCardCacheState() {
    const stored = await chrome.storage.local.get([
        TEMP_EMAIL_CARD_CACHE_LIST_KEY,
        TEMP_EMAIL_CARD_SELECTED_ID_KEY,
        TEMP_EMAIL_CARD_CACHE_KEY,
        TEMP_EMAIL_CARD_CACHE_NAME_KEY,
        TEMP_EMAIL_CARD_CACHE_TIME_KEY
    ]);

    const list = Array.isArray(stored[TEMP_EMAIL_CARD_CACHE_LIST_KEY]) ? stored[TEMP_EMAIL_CARD_CACHE_LIST_KEY] : [];
    if (list.length > 0) {
        const items = list.map((item, index) => normalizeTempEmailCardCacheEntry(item, index));
        let selectedId = String(stored[TEMP_EMAIL_CARD_SELECTED_ID_KEY] || '').trim();
        if (!selectedId || !items.some((item) => item.id === selectedId)) {
            selectedId = String(items[0]?.id || '').trim();
        }
        return { items, selectedId };
    }

    const legacyCard = stored[TEMP_EMAIL_CARD_CACHE_KEY];
    if (legacyCard && typeof legacyCard === 'object') {
        const legacyItem = normalizeTempEmailCardCacheEntry({
            id: 'legacy-temp-email-card',
            cardData: legacyCard,
            cardName: stored[TEMP_EMAIL_CARD_CACHE_NAME_KEY] || legacyCard.name || '',
            savedAt: stored[TEMP_EMAIL_CARD_CACHE_TIME_KEY] || new Date().toISOString(),
            sourceName: stored[TEMP_EMAIL_CARD_CACHE_NAME_KEY] || ''
        }, 0);
        return {
            items: [legacyItem],
            selectedId: legacyItem.id
        };
    }

    return { items: [], selectedId: '' };
}

async function saveTempEmailCardCacheState(items = [], selectedId = '') {
    const normalizedItems = Array.isArray(items) ? items.map((item, index) => normalizeTempEmailCardCacheEntry(item, index)) : [];
    const normalizedSelectedId = String(selectedId || normalizedItems[0]?.id || '').trim();
    await chrome.storage.local.set({
        [TEMP_EMAIL_CARD_CACHE_LIST_KEY]: normalizedItems,
        [TEMP_EMAIL_CARD_SELECTED_ID_KEY]: normalizedSelectedId,
        [TEMP_EMAIL_CARD_CACHE_KEY]: normalizedItems.find((item) => item.id === normalizedSelectedId)?.cardData || normalizedItems[0]?.cardData || {},
        [TEMP_EMAIL_CARD_CACHE_NAME_KEY]: normalizedItems.find((item) => item.id === normalizedSelectedId)?.cardName || normalizedItems[0]?.cardName || '',
        [TEMP_EMAIL_CARD_CACHE_TIME_KEY]: normalizedItems.find((item) => item.id === normalizedSelectedId)?.savedAt || normalizedItems[0]?.savedAt || ''
    }).catch(() => {});
    return {
        items: normalizedItems,
        selectedId: normalizedSelectedId
    };
}

async function refreshTempEmailCardCacheUi() {
    const message = '临时邮箱卡片 JSON 已废弃，当前仅保留软件 HTTP 控制';
    if (tempEmailCardCacheListNode) {
        tempEmailCardCacheListNode.innerHTML = `<div class="card-cache-empty">${escapeHtml(message)}</div>`;
    }
    setTempEmailCacheBadge('已废弃');
    return { items: [], selectedId: '' };
}

async function selectTempEmailCardCacheItem(cardId) {
    void cardId;
    throw new Error('临时邮箱卡片 JSON 已废弃，请直接使用软件 HTTP 控制');
}

async function upsertTempEmailCardCache(cardData, options = {}) {
    const safeCardData = normalizeTempEmailCardData(cardData, cardData?.name || options.fileName || 'temp-email');
    const state = await loadTempEmailCardCacheState().catch(() => ({ items: [], selectedId: '' }));
    const existingIndex = state.items.findIndex((item) => item.id === (options.id || state.selectedId));
    const nextItem = normalizeTempEmailCardCacheEntry({
        id: options.id || (options.append === true ? buildTempEmailCardCacheId(safeCardData, options.fileName || safeCardData.name) : (state.selectedId || buildTempEmailCardCacheId(safeCardData, options.fileName || safeCardData.name))),
        cardData: safeCardData,
        cardName: safeCardData.name,
        sourceName: options.fileName || safeCardData.name,
        savedAt: new Date().toISOString()
    });

    const nextItems = state.items.slice();
    if (existingIndex >= 0) {
        nextItems.splice(existingIndex, 1, nextItem);
    } else {
        nextItems.push(nextItem);
    }

    const nextSelectedId = options.select === false ? state.selectedId || nextItem.id : nextItem.id;
    await saveTempEmailCardCacheState(nextItems, nextSelectedId);
    renderTempEmailCardCacheList({ items: nextItems, selectedId: nextSelectedId });
    return {
        cardData: safeCardData,
        cardName: safeCardData.name,
        id: nextItem.id,
        selectedId: nextSelectedId
    };
}

async function importSelectedTempEmailCardFilesToCache() {
    const files = Array.from(tempEmailCardFileInput?.files || []).filter(Boolean);
    if (!files.length) {
        return null;
    }

    const items = [];
    for (const file of files) {
        const rawText = await file.text();
        let cardData;
        try {
            cardData = JSON.parse(rawText);
        } catch (_error) {
            throw new Error(`临时邮箱卡片文件不是有效的 JSON: ${file.name}`);
        }

        const result = await upsertTempEmailCardCache(cardData, {
            append: true,
            select: false,
            fileName: file.name
        });
        items.push({
            id: result.id,
            cardData: result.cardData,
            cardName: result.cardName,
            savedAt: new Date().toISOString(),
            sourceName: file.name
        });
    }

    const selectedItem = items[items.length - 1] || null;
    if (selectedItem) {
        const state = await loadTempEmailCardCacheState().catch(() => ({ items: [], selectedId: '' }));
        await saveTempEmailCardCacheState(state.items, selectedItem.id);
        renderTempEmailCardCacheList({
            items: state.items,
            selectedId: selectedItem.id
        });
        setTempEmailCacheBadge(`${state.items.length} 张`);
    }

    if (tempEmailCardFileInput) {
        tempEmailCardFileInput.value = '';
    }

    return {
        items,
        selectedItem
    };
}

async function saveTempEmailCardCache(cardData) {
    const result = await upsertTempEmailCardCache(cardData, { select: true });
    return result.cardData;
}

async function loadTempEmailCardCache() {
    const state = await loadTempEmailCardCacheState();
    if (!state.items.length) {
        return null;
    }

    const selectedCard = state.items.find((item) => item.id === state.selectedId) || state.items[0];
    if (!selectedCard) {
        return null;
    }

    return {
        cardData: selectedCard.cardData,
        cardName: String(selectedCard.cardName || selectedCard.cardData?.name || '').trim(),
        savedAt: String(selectedCard.savedAt || '').trim(),
        items: state.items,
        selectedId: state.selectedId
    };
}

async function clearTempEmailCardCache() {
    await chrome.storage.local.remove([
        TEMP_EMAIL_CARD_CACHE_LIST_KEY,
        TEMP_EMAIL_CARD_SELECTED_ID_KEY,
        TEMP_EMAIL_CARD_CACHE_KEY,
        TEMP_EMAIL_CARD_CACHE_NAME_KEY,
        TEMP_EMAIL_CARD_CACHE_TIME_KEY
    ]).catch(() => {});
    if (tempEmailCardFileInput) {
        tempEmailCardFileInput.value = '';
    }
    await refreshTempEmailCardCacheUi().catch(() => {});
}

function setTempEmailCacheBadge(text = '') {
    if (!tempEmailCacheBadgeNode) {
        return;
    }
    tempEmailCacheBadgeNode.textContent = text || '无';
}


globalThis.CookieCaptureTempEmail = {
    normalizeTempEmailCardData,
    buildTempEmailCardCacheId,
    normalizeTempEmailCardCacheEntry,
    buildTempEmailCardListLabel,
    renderTempEmailCardCacheList,
    loadTempEmailCardCacheState,
    saveTempEmailCardCacheState,
    refreshTempEmailCardCacheUi,
    selectTempEmailCardCacheItem,
    upsertTempEmailCardCache,
    importSelectedTempEmailCardFilesToCache,
    saveTempEmailCardCache,
    loadTempEmailCardCache,
    clearTempEmailCardCache,
    setTempEmailCacheBadge
};
